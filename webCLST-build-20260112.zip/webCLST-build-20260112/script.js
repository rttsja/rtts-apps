// Function to show/hide the ticket number field
function toggleTicketField(show) {
    const container = document.getElementById('ticketNumberContainer');
    const iticketInput = document.getElementById('iticketNumber');
    const eticketInput = document.getElementById('eticketNumber');
    if (container) container.style.display = show ? 'block' : 'none';
    if (!show && iticketInput && eticketInput) {
        iticketInput.value = '';
        eticketInput.value = '';
    }
}

// --- Core Logging Functions ---

function saveLogEntry(entry) {
    const logs = JSON.parse(localStorage.getItem('callLogs') || '[]');
    logs.push(entry);
    localStorage.setItem('callLogs', JSON.stringify(logs));
    displayLogEntries();
}

function displayLogEntries() {
    const logEntriesDiv = document.getElementById('logEntries');
    if (!logEntriesDiv) return;
    
    logEntriesDiv.innerHTML = '';
    const logs = JSON.parse(localStorage.getItem('callLogs') || '[]');
    
    logs.reverse().forEach(log => {
        const entryDiv = document.createElement('div');
        entryDiv.classList.add('log-entry');
        
// FIX: Variable names now match the logEntry object keys exactly
        entryDiv.innerHTML = `
            <strong><strong>Time:</strong> ${new Date(log.timestamp).toLocaleString('en-US', { 
                                timeZone: 'America/Jamaica', 
                                hour12: true 
                            })}<br>
            <strong>Caller Name:</strong> ${log.callerName} <br>
            <strong>Caller Number:</strong> ${log.Caller_Number} <br>
            <strong>Email:</strong> ${log.Caller_Email} <br>
            <strong>Customer / Business:</strong> ${log.Customer_Name} <br>
            <strong>Circuit ID [CID]:</strong> ${log.Customer_CID_Number} <br>
            <strong>Location:</strong> ${log.Customer_Location} <br>
            <strong>Service Type:</strong> ${log.serviceType} <br>
            <strong>Issue / Request:</strong> ${log.issueType} <br>
            <strong>Issue Started:</strong> ${log.issueDate ? new Date(log.issueDate).toLocaleString('en-US', { timeZone: 'America/Jamaica', hour12: true }) : 'N/A'} <br>
            <strong>Call Direction:</strong> ${log.callType || 'N/A'} <br>
            <strong>CCR #:</strong> ${log.iticketNumber} <br>
            <strong>eTTK #:</strong> ${log.eticketNumber} <br>
            <strong>Notes / Comments:</strong> ${log.notes}
        `;
        logEntriesDiv.appendChild(entryDiv);
    });
}

function downloadTxtFile(content, filename) {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);
}

function clearLog() {
    if (confirm("Are you sure you want to clear the entire call log?")) {
        if (confirm("Would you like to download a backup CSV before clearing?")) {
            downloadLog();
        }
        localStorage.removeItem('callLogs');
        displayLogEntries();
    }
}

function downloadLog() {
    const logs = JSON.parse(localStorage.getItem('callLogs') || '[]');
    if (logs.length === 0) {
        alert("No logs to download.");
        return;
    }
    
    const headers = Object.keys(logs[0]);
    const csvRows = [headers.join(",")];

    for (const log of logs) {
        const values = headers.map(header => {
            const escaped = ('' + (log[header] || '')).replace(/"/g, '""');
            return `"${escaped}"`;
        });
        csvRows.push(values.join(","));
    }

    const blob = new Blob([csvRows.join("\n")], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute("download", "call_log.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// --- Form Submission Handler ---
const callLogForm = document.getElementById('callLogForm');
if (callLogForm) {
    callLogForm.addEventListener('submit', function(event) {
        event.preventDefault();
        
        const logEntry = {
            iticketNumber: document.getElementById('iticketNumber')?.value || 'N/A',
            // Reverted: Saving as a formatted string immediately
            timestamp: new Date().toLocaleString('en-US', { timeZone: 'America/Jamaica', hour12: true }),
            callerName: document.getElementById('callerName').value,
            Caller_Number: document.getElementById('Caller_Number').value,
            Caller_Email: document.getElementById('Caller_Email').value,
            Customer_Name: document.getElementById('Customer_Name').value,
            Customer_CID_Number: document.getElementById('Customer_CID_Number').value,
            Customer_Location: document.getElementById('Customer_Location').value,
            serviceType: document.getElementById('serviceType').value,
            issueType: document.getElementById('issueType').value,
            issueDate: document.getElementById('issueDate').value,
            callType: document.getElementById('callType')?.value || 'Inbound', 
            eticketNumber: document.getElementById('eticketNumber')?.value || 'N/A',
            notes: document.getElementById('notes').value.replace(/\n/g, ' ')
        };

        if (document.getElementById('downloadAsTextCheckbox')?.checked) {
            let textContent = `TECH log entry:\n`;
            for (const key in logEntry) {
                textContent += `${key}: ${logEntry[key]}\n`;
            }
            const dateString = new Date().toISOString().slice(0, 10);
            const name = logEntry.Customer_Name || "Unknown";
            const cid = logEntry.Customer_CID_Number || "000";
            const filename = `TECH-${name}-${cid}-${dateString}.txt`;
            downloadTxtFile(textContent, filename);
        }

        saveLogEntry(logEntry);
        this.reset();
    });
}

document.addEventListener('DOMContentLoaded', displayLogEntries);

function toggleDropdown() {
    const dropdown = document.getElementById("settingsDropdown");
    const arrow = document.querySelector(".arrow");
    if (dropdown) dropdown.classList.toggle("show");
    if (arrow) arrow.classList.toggle("show-arrow");
}

window.onclick = function(event) {
    if (!event.target.matches('.dropbtn') && !event.target.closest('.dropbtn') && !event.target.matches('.arrow')) {
        const dropdowns = document.getElementsByClassName("dropdown-content");
        const arrow = document.querySelector(".arrow");

        for (let i = 0; i < dropdowns.length; i++) {
            if (dropdowns[i].classList.contains('show')) {
                dropdowns[i].classList.remove('show');
            }
        }
        if (arrow) arrow.classList.remove('show-arrow');
    }
};
// Fixed Directory Picker (Note: Only works in HTTPS and modern browsers)
async function openLocalFolder() {
  try {
    if ('showDirectoryPicker' in window) {
        const directoryHandle = await window.showDirectoryPicker();
        alert("Folder access granted! Check console for file list.");
        for await (const entry of directoryHandle.values()) {
          console.log(entry.kind, entry.name);
        }
    } else {
        alert("Your browser does not support the File System Access API. Please use Ctrl+J to view downloads.");
    }
  } catch (err) {
    if (err.name !== 'AbortError') {
      console.error(err);
      alert("Note: Browsers cannot open File Explorer directly for security.");
    }
  }
}
// Use 'input' instead of 'change' for immediate updates
document.getElementById('issueDate').addEventListener('input', function() {
    const selectedValue = this.value;
    
    // In 2026, partial entries return an empty string; wait for complete input
    if (!selectedValue) return;

    // Create a Date object from the input string (YYYY-MM-DDTHH:mm)
    const dateObj = new Date(selectedValue);

    // Format to 12-hour clock in Eastern Standard Time (America/Jamaica)
    const estFormatter = new Intl.DateTimeFormat('en-US', {
        timeZone: 'America/Jamaica', // Fixed to Jamaica time year-round
        year: 'numeric',
        day: '2-digit',
        month: '2-digit',
        hour: 'numeric',
        minute: '2-digit',
        hour12: true,
        timeZoneName: 'short'
    });

    const formattedDate = estFormatter.format(dateObj);
    
    // Update display
    document.getElementById('output').textContent = formattedDate;
    console.log("Saved Output (EST):", formattedDate);
});

const serviceSelect = document.getElementById('serviceType');

serviceSelect.addEventListener('input', function() {
    // Array 1: LCON and Access Hours requirements
    const contactRequirements = ['Ethernet / DIA', 'Commercial Internet', 'FTTT'];
    
    // Array 2: OTDR Shot requirements
    const otdrRequirements = ['Dark Fiber', 'DS3', 'Wave', 'Optical Transport Service'];

    if (contactRequirements.includes(this.value)) {
        alert(`SERVICE TYPE:    ${this.value} \nPlease request LCON, Access Hours and Gate/Rack Codes!`);
    } else if (otdrRequirements.includes(this.value)) {
        alert(`SERVICE TYPE:    ${this.value} \nPlease request email of OTDR Shots!`);
    }
});
