Add-Type -AssemblyName System.Windows.Forms, System.Drawing

# --- 1. INITIALIZATION: Root Folder Selection ---
# Prompt user before the form launches
[System.Windows.Forms.MessageBox]::Show($disclaimertext)
[Windows.Forms.MessageBox]::Show("Select the webCLST Root Folder.", "Initial Setup")

$initialFolderBrowser = New-Object System.Windows.Forms.FolderBrowserDialog
$initialFolderBrowser.Description = "Select the webCLST Root Folder"
$initialFolderBrowser.RootFolder = "MyComputer"

if ($initialFolderBrowser.ShowDialog() -eq "OK") {
    $clst_root = $initialFolderBrowser.SelectedPath
} else {
    [Windows.Forms.MessageBox]::Show("No folder selected. Some features may not work.", "Warning")
    $clst_root = ""
}

# --- 2. Functions ---
function sync_clog {
    param($path)
    Write-Host "Processing: $path"
    
    if (-not (Test-Path $path)) {
        Write-Error "Target Excel file not found: $path"
        return
    }

    $csvPath = "$env:USERPROFILE\Downloads\call_log.csv"
    if (-not (Test-Path $csvPath)) {
        Write-Error "CSV file not found: $csvPath"
        return
    }

    $csvData = Import-Csv -Path $csvPath
    $Excel = New-Object -ComObject Excel.Application
    $Excel.Visible = $false
    $Excel.DisplayAlerts = $false

    try {
        $Workbook = $Excel.Workbooks.Open($path)
        $Year = (Get-Date).Year
        $SheetName = "clog$Year"
        
        try {
            $Worksheet = $Workbook.Worksheets.Item($SheetName)
        } catch {
            Write-Error "Sheet '$SheetName' not found in $path"
            return
        }

        $Worksheet.Unprotect($SheetName)
        $xlUp = -4162
        $lastRow = $Worksheet.Cells.Item(1048576, 2).End($xlUp).Row
        $currentRow = $lastRow + 1
        
        foreach ($row in $csvData) {
            $Worksheet.Cells.Item($currentRow, 2).Value = $row.iticketNumber
            $Worksheet.Cells.Item($currentRow, 3).Value = $row.timestamp
            $Worksheet.Cells.Item($currentRow, 4).Value = $row.callerName
            $Worksheet.Cells.Item($currentRow, 5).Value = $row.Caller_Number
            $Worksheet.Cells.Item($currentRow, 6).Value = $row.Caller_Email
            $Worksheet.Cells.Item($currentRow, 7).Value = $row.Customer_Name
            $Worksheet.Cells.Item($currentRow, 8).Value = $row.Customer_CID_Number
            $Worksheet.Cells.Item($currentRow, 9).Value = $row.Customer_Location
            $Worksheet.Cells.Item($currentRow, 10).Value = $row.serviceType
            $Worksheet.Cells.Item($currentRow, 11).Value = $row.issueType       
            $Worksheet.Cells.Item($currentRow, 13).Value = "$($row.notes) | $($row.issueDate) | $($row.eticketNumber)"
            $currentRow++
        }

        $Workbook.Save()
        Write-Host "Successfully updated $path" -ForegroundColor Green
    }
    catch {
        Write-Error "An error occurred: $($_.Exception.Message)"
    }
    finally {
        if ($Workbook) { $Workbook.Close($true); [System.Runtime.InteropServices.Marshal]::ReleaseComObject($Workbook) | Out-Null }
        if ($Excel) { $Excel.Quit(); [System.Runtime.InteropServices.Marshal]::ReleaseComObject($Excel) | Out-Null }
        [System.GC]::Collect()
        [System.GC]::WaitForPendingFinalizers()
    }
}

function Set-WallpaperToRoot {
    param($SourceImage)
    
    # Use $clst_root if it exists, otherwise ask for folder
    $targetDir = $clst_root
    if (-not (Test-Path $targetDir)) {
        [Windows.Forms.MessageBox]::Show("Root folder not set. Please select folder to save background.", "Select Folder")
        $fb = New-Object System.Windows.Forms.FolderBrowserDialog
        if ($fb.ShowDialog() -eq "OK") { $targetDir = $fb.SelectedPath } else { return }
    }

    $destination = Join-Path $targetDir "bground.jpg"
    try {
        Copy-Item -Path $SourceImage -Destination $destination -Force
        [Windows.Forms.MessageBox]::Show("Wallpaper updated: $destination", "Success")
    } catch {
        [Windows.Forms.MessageBox]::Show("Failed to copy wallpaper: $($_.Exception.Message)", "Error")
    }
}

#>>>..................................Add About & Disclaimer Text...............................
$abouttext = "The web-based CLST app automates the collection and logging of
 caller queries.
 
 This is a proof of concept, but has been adapted
 for individual use cases.
 
 This app is strictly intended for test purposes and
 is not for commercial use.
 
 This app should NOT be used for production purposes.
 Use at own discression and risk."
#.......................................................
$disclaimertext = $text = "                 | webCLST app; release date:Jan 12th,2026 | `n`nThank you for using our launcher tool for our web based CLST tool. "

#............................................END..............................................................
function Open-update {
    Start-Process https://github.com/rttsja/rtts-apps.git
}
#...

function uninstall_rtts {
        # If the current directory is within the folder to delete, switch to a different directory first
        if ("$($PWD.Path)\\" -like "$PSScriptRoot\\*") {
            Push-Location C:\ 
        }
        # Remove the script's parent folder as a whole
        Remove-Item -LiteralPath $PSScriptRoot -Recurse -Force
    }
#.....................................Add File Menu Strip...............................................
  $menuStrip = New-Object System.Windows.Forms.MenuStrip
  $fileMenu = New-Object System.Windows.Forms.ToolStripMenuItem("Menu")
  $fileMenu.Font = New-Object System.Drawing.Font("Arial",10,[System.Drawing.FontStyle]::Bold)
  $menuStrip.Items.Add($fileMenu)
  
  $openMenuItem = New-Object System.Windows.Forms.ToolStripMenuItem("Open Dir / File")
  $fileMenu.DropDownItems.Add($openMenuItem)
   
  $fileExplorer = New-Object System.Windows.Forms.ToolStripMenuItem("Open File Explorer")
  $openMenuItem.DropDownItems.Add($fileExplorer)
    
  $aboutMenuItem = New-Object System.Windows.Forms.ToolStripMenuItem("App Info")
  $fileMenu.DropDownItems.Add($aboutMenuItem)
  
  $openAbout = New-Object System.Windows.Forms.ToolStripMenuItem("About app")
  $aboutMenuItem.DropDownItems.Add($openAbout)
  
  $updateCheck = New-Object System.Windows.Forms.ToolStripMenuItem("Check for Update")
  $aboutMenuItem.DropDownItems.Add($updateCheck)

  $uninstall_rtts = New-Object System.Windows.Forms.ToolStripMenuItem("uninstall app")
  $aboutMenuItem.DropDownItems.Add($uninstall_rtts)
  
 
  $exitMenuItem = New-Object System.Windows.Forms.ToolStripMenuItem("Exit")
  $fileMenu.DropDownItems.Add($exitMenuItem)
  #........................................# Add an event handler for Menu item button click
 $fileExplorer.Add_Click({
    explorer /select, $clst_root
     })
  $enocTExplorer.Add_Click({
    open_working_dir
     })
  #-----------------------
 $openAbout.Add_Click({
    [System.Windows.Forms.MessageBox]::Show("$abouttext")
     })
  #-----------------------
 $uninstall_rtts.Add_Click({
    uninstall_rtts
    })
 #-----------------------
 $openMenuItem
 #-----------------------
 $updateCheck.Add_Click({
  [System.Windows.Forms.MessageBox]::Show("Launching Github site to check for Update")   
  Open-update
     })
 $exitMenuItem.Add_Click({
    $form.Close()
    }) 


# --- 3. Form Configuration --- 
function launchFORM{  
$form = New-Object Windows.Forms.Form
$form.Text = "launcher webCLST"
$form.Size = "500, 320"
$form.BackColor = [Drawing.Color]::FromArgb(33, 33, 33) 
$form.Opacity = 0.95 
$form.StartPosition = "CenterScreen"

# Display the current root path at the bottom
$lblRoot = New-Object System.Windows.Forms.Label
$lblRoot.Text = "Root: $clst_root"
$lblRoot.ForeColor = [Drawing.Color]::Gray
$lblRoot.Dock = "Bottom"
$lblRoot.TextAlign = "MiddleCenter"
$form.Controls.Add($lblRoot)
$form.Controls.Add($menuStrip)

# --- 4. UI Element Helper ---
function New-MaterialButton($Text, $PosX, $IconPath) {
    $btn = New-Object Windows.Forms.Button
    $btn.Size = "150, 150"
    $btn.Location = "$PosX, 60"
    $btn.FlatStyle = "Flat"
    $btn.FlatAppearance.BorderSize = 0
    $btn.BackColor = [Drawing.Color]::FromArgb(60, 60, 60)
    $btn.ForeColor = [Drawing.Color]::White
    $btn.Font = "Segoe UI Semibold, 11pt"
    
    if (Test-Path $IconPath) {
        $img = [Drawing.Image]::FromFile($IconPath)
        $btn.BackgroundImage = [Drawing.Bitmap]::new($img, [Drawing.Size]::new(100, 100))
        $btn.BackgroundImageLayout = "Center"
    }
    
    $btn.Text = $Text
    $btn.TextAlign = "BottomCenter"
    $btn.Padding = "0, 0, 0, 8"
    return $btn
}

# --- 5. Controls ---
$btnSync = New-MaterialButton -Text "Sync Log" -PosX 50 -IconPath "$clst_root\sync.png"
$btnWeb = New-MaterialButton -Text "WebCLST Tool" -PosX 296 -IconPath "$clst_root\wlog.png"

$chkWallpaper = New-Object System.Windows.Forms.CheckBox
$chkWallpaper.Text = "Change clog Wallpaper"
$chkWallpaper.Location = "300, 220"
$chkWallpaper.AutoSize = $true
$chkWallpaper.ForeColor = [Drawing.Color]::White
$chkWallpaper.Font = "Segoe UI, 10pt"

$form.Controls.AddRange(@($btnSync, $btnWeb, $chkWallpaper))

# --- 6. Events ---
$btnSync.Add_Click({
    [Windows.Forms.MessageBox]::Show("Choose clog file for synchronization.", "Selection Required")
    $excelDialog = New-Object System.Windows.Forms.OpenFileDialog
    $excelDialog.Title = "Select Excel File"
    $excelDialog.Filter = "Excel Files (*.xlsx)|*.xlsx"
    if ($excelDialog.ShowDialog() -eq "OK") {
        sync_clog -path $excelDialog.FileName
        $csvPath = "$env:USERPROFILE\Downloads\call_log.csv"
        if (Test-Path $csvPath) { Remove-Item $csvPath -Force }
        [Windows.Forms.MessageBox]::Show("Process Finished.", "clog now Synched")
    }
})

$btnWeb.Add_Click({
    if ($chkWallpaper.Checked) {
        [Windows.Forms.MessageBox]::Show("Please select the image file you wish to use as your wallpaper.", "Step 1: Select Image")
        $fb = New-Object System.Windows.Forms.OpenFileDialog
        $fb.Title = "Select Wallpaper Image"
        $fb.Filter = "Image Files (*.jpg;*.jpeg;*.png)|*.jpg;*.jpeg;*.png"
        if ($fb.ShowDialog() -eq "OK") {
            Set-WallpaperToRoot -SourceImage $fb.FileName
        }
    }

    # First, try to find index.html in the selected $clst_root
    $targetHtml = Join-Path $clst_root "index.html"

    if (Test-Path $targetHtml) {
        Start-Process $targetHtml
    } else {
        [Windows.Forms.MessageBox]::Show("index.html not found in root. Searching Downloads...", "File Not Found")
        
        $searchPattern = "$env:USERPROFILE\Downloads\webCLST*\index.html"
        $foundFile = Get-Item $searchPattern -ErrorAction SilentlyContinue | Select-Object -First 1

        if ($foundFile) {
            Start-Process $foundFile.FullName
        } else {
            [Windows.Forms.MessageBox]::Show("Could not find index.html automatically. Please locate manually.", "Manual Selection")
            $htmlDialog = New-Object System.Windows.Forms.OpenFileDialog
            $htmlDialog.Title = "Locate index.html"
            $htmlDialog.Filter = "HTML Files (*.html)|*.html"
            if ($htmlDialog.ShowDialog() -eq "OK") { Start-Process $htmlDialog.FileName }
        }
    }
})

[void]$form.ShowDialog()
}
launchFORM